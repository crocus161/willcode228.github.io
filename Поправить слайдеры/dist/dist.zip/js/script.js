
  $('.examples__list_3').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false
  });
  $('.introduction__list_3').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false
  });
      