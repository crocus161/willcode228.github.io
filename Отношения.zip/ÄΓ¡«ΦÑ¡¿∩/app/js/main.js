window.addEventListener('load', () => {
    const $ = elem => document.querySelector(elem);

    const nav_close = $('.nav__list-close'),
        nav_open = $('.nav__open'),
        nav_list = $('.nav__list');

    nav_open.addEventListener('click', () => {
        nav_list.classList.add('nav__list-active');
    });
    nav_close.addEventListener('click', () => {
        nav_list.classList.remove('nav__list-active');
    });

//     const effect_title = $('.scroll__effect-text');
//     const default_size = parseInt(window.getComputedStyle(effect_title).fontSize);
//     let default_scroll = 0;
//     window.addEventListener('scroll', () => {
//         if(default_scroll < scrollY){
//             default_scroll = scrollY;
//             console.log('down');
//             effect_title.style.fontSize = `${parseInt(window.getComputedStyle(effect_title).fontSize) + 1}px`;
//         }else if(default_scroll > scrollY){
//             default_scroll = scrollY;
//             console.log('up');
//             effect_title.style.fontSize = `${parseInt(window.getComputedStyle(effect_title).fontSize) - 1}px`;
//         } 
//     });
});